<div class="sidebar">
    <ul>
        <li><a href="{{ route('admin.dashboard') }}">Dashboard</a></li>
        <li><a href="{{ route('admin.users') }}">Users</a></li>
        <li><a href="{{ route('admin.prospects') }}">Prospects</a></li>
        <!-- Ajoutez d'autres liens de menu ici selon vos besoins -->
    </ul>
</div>