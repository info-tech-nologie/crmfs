<div class="card">
    <div class="card-header">
        Menu
    </div>
    <ul class="list-group list-group-flush">
        <li class="list-group-item"><a href="{{ route('admin.users') }}">Manage Users</a></li>
        <li class="list-group-item"><a href="#">Placeholder</a></li>
        <li class="list-group-item"><a href="#">Placeholder</a></li>
        <li class="list-group-item"><a href="#">Placeholder</a></li>
    </ul>
</div>