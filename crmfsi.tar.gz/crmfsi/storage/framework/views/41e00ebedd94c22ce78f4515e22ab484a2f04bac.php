<div class="sidebar">
    <ul>
        <li><a href="<?php echo e(route('admin.dashboard')); ?>">Dashboard</a></li>
        <li><a href="<?php echo e(route('admin.users')); ?>">Users</a></li>
        <li><a href="<?php echo e(route('admin.prospects')); ?>">Prospects</a></li>
        <!-- Ajoutez d'autres liens de menu ici selon vos besoins -->
    </ul>
</div><?php /**PATH /root/crmfsi/resources/views/admin/includes/sidebar.blade.php ENDPATH**/ ?>